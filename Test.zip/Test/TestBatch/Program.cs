﻿using System;

namespace TestBatch
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            //will write the batch scenario or HangFire(extension)
            //automated scenario to execute the Method to Generate Invoice 
            //and send mail to Customers
        }
    }
}
