﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using TestModel.Models.Payments;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InvoiceController : ControllerBase
    {
        //ITimeMaterialDomain
        public InvoiceController()
        {
            //ITimeMaterialDomain
        }

        //will be calling ITimeMaterialDomain => GenerateInvoice

        public void UploadTransactions()
        {
            //Upload files hits this method

            var dataFromExcel = new List<Payment>();
            //convert data into this model

            //will be calling ITimeMaterialDomain => CheckTransactions
        }
    }
}
