﻿using System;
using System.Collections.Generic;
using TestModel.Models;
using TestModel.Models.Payments;

namespace WebApplication1.Domain.interfaces
{
    public interface ITimeMaterialDomain
    {
        void LoggingTime(TimeMaterial timematerial);

        decimal GenerateInvoice(Guid projectId);

        decimal CheckTransactions(List<Payment> payments);
    }
}
