﻿using System;
using System.Collections.Generic;
using System.Linq;
using TestModel.Models;
using TestModel.Models.Payments;
using WebApplication1.Domain.interfaces;

namespace WebApplication1.Domain
{
    public class TimeMateralDomain : ITimeMaterialDomain
    {
        public decimal CheckTransactions(List<Payment> payments)
        {
            var projects = payments.GroupBy(x => x.ProjectId).ToList();

            foreach (var project in projects)
            {
                var paymentTotal = 0.0M;
                foreach (var payment in project)
                {
                    paymentTotal += payment.Amount;
                }
                var invoiceAmount = GenerateInvoice(project.Key);
                if (invoiceAmount == paymentTotal)
                {
                    Console.WriteLine($"Total Payment for Client Project {project.Key} is {paymentTotal}");
                }
                else
                {
                    Console.WriteLine("Please Calculate Once again");
                }
            }

            throw new NotImplementedException();
        }

        public decimal GenerateInvoice(Guid projectId)
        {
            //InvoiceAmount

            var ratePerHour = new Project();
            //get the ratePerHour For ProjectId

            var payments = new List<TimeMaterial>();

            var employees = payments.Where(z => z.ProjectId == projectId).GroupBy(x => x.EmployeeId).ToList();

            var totalHours = 0;
            foreach (var employee in employees)
            {
                var employeeHours = 0;
                foreach (var time in employee)
                {
                    employeeHours += time.HoursWorked;
                }
                Console.WriteLine($"Total Hours for Employee {employee.Key} is {employeeHours}");
                totalHours += employeeHours;
            }
            Console.WriteLine($"Total Hours for Invoice Amount is {totalHours * ratePerHour.RatePerHour}");

            return totalHours * ratePerHour.RatePerHour;
        }

        public void LoggingTime(TimeMaterial timematerial)
        {
            //logging into database based on the input
            throw new NotImplementedException();
        }
    }
}
