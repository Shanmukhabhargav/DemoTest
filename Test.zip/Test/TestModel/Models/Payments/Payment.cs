﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestModel.Enums;

namespace TestModel.Models.Payments
{
    public class Payment
    {
        public DateTime Date { get; set; }
        public PaymentType PaymentType { get; set; }
        public decimal Amount { get; set; }
        public Guid ProjectId { get; set; }
    }
}
