﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestModel.Enums;

namespace TestModel.Models
{
    public class TimeMaterial
    {
        public Guid ProjectId { get; set; }
        public string EmployeeId { get; set; }
        public int MilestoneId { get; set; }
        public int HoursWorked { get; set; }
    }
}
