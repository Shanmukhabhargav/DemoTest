﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestModel.Enums;

namespace TestModel.Models
{
    public class Project
    {
        public Guid ProjectId { get; set; }
        public string ProjectName { get; set; }
        public int RatePerHour { get; set; }
        public BillingMode BillingMode { get; set; }
    }
}
